import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function CommunityPage() {
  const socialLinks = [
    { name: "Twitter", url: "#", icon: "🐦", description: "Follow us for updates" },
    { name: "Telegram", url: "#", icon: "📱", description: "Join our community chat" },
    { name: "Discord", url: "#", icon: "💬", description: "Connect with other holders" },
    { name: "Reddit", url: "#", icon: "🔴", description: "Discuss and share ideas" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-8">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Community
              </span>
            </h1>

            <p className="text-xl text-muted-foreground text-center mb-12">
              Join thousands of supporters in the digital revolution for equality and justice.
            </p>

            <div className="grid md:grid-cols-2 gap-6 mt-12">
              {socialLinks.map((link, index) => (
                <Card
                  key={index}
                  className="p-6 bg-card/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className="text-4xl">{link.icon}</div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-foreground">{link.name}</h3>
                      <p className="text-muted-foreground">{link.description}</p>
                    </div>
                    <Button
                      variant="outline"
                      className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                    >
                      Join
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
