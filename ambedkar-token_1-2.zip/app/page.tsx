"use client"

import { useState, useEffect } from "react"
import { CinematicIntro } from "@/components/cinematic-intro"
import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { MetricsDashboard } from "@/components/metrics-dashboard"

export default function HomePage() {
  const [showIntro, setShowIntro] = useState(true)
  const [introComplete, setIntroComplete] = useState(false)

  useEffect(() => {
    // Force intro to show for better user experience
    setShowIntro(true)
    setIntroComplete(false)
  }, [])

  const handleIntroComplete = () => {
    console.log("[v0] Intro completed")
    setShowIntro(false)
    setIntroComplete(true)
  }

  const handleSkipIntro = () => {
    console.log("[v0] Intro skipped")
    setShowIntro(false)
    setIntroComplete(true)
  }

  if (showIntro) {
    return <CinematicIntro onComplete={handleIntroComplete} onSkip={handleSkipIntro} />
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <MetricsDashboard />
      </main>
    </div>
  )
}
