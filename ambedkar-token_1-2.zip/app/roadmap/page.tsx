import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"

export default function RoadmapPage() {
  const roadmapItems = [
    {
      phase: "Phase 1",
      title: "Token Launch",
      status: "completed",
      items: ["Token creation on Solana", "Initial community building", "Pump.fun listing"],
    },
    {
      phase: "Phase 2",
      title: "Community Growth",
      status: "current",
      items: ["Social media campaigns", "Partnership development", "Educational content"],
    },
    {
      phase: "Phase 3",
      title: "DEX Listing",
      status: "upcoming",
      items: ["Major DEX listings", "Liquidity provision", "Trading pairs expansion"],
    },
    {
      phase: "Phase 4",
      title: "Ecosystem Development",
      status: "upcoming",
      items: ["DeFi integrations", "NFT collections", "Governance implementation"],
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-8">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Roadmap
              </span>
            </h1>

            <div className="space-y-8 mt-12">
              {roadmapItems.map((item, index) => (
                <Card
                  key={index}
                  className={`p-6 bg-card/50 backdrop-blur-sm border-l-4 ${
                    item.status === "completed"
                      ? "border-l-green-500"
                      : item.status === "current"
                        ? "border-l-primary"
                        : "border-l-muted"
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-2xl font-bold text-foreground">
                      {item.phase}: {item.title}
                    </h3>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        item.status === "completed"
                          ? "bg-green-500/20 text-green-500"
                          : item.status === "current"
                            ? "bg-primary/20 text-primary"
                            : "bg-muted/20 text-muted-foreground"
                      }`}
                    >
                      {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </span>
                  </div>
                  <ul className="space-y-2">
                    {item.items.map((subItem, subIndex) => (
                      <li key={subIndex} className="flex items-center text-muted-foreground">
                        <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                        {subItem}
                      </li>
                    ))}
                  </ul>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
