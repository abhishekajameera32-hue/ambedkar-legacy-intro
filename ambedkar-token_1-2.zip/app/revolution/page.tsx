import { Header } from "@/components/header"

export default function RevolutionPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-8">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                The Digital Revolution
              </span>
            </h1>
            <div className="prose prose-lg max-w-none text-foreground">
              <p className="text-xl text-muted-foreground text-center mb-12">
                Dr. B.R. Ambedkar's vision of equality and justice, powered by blockchain technology.
              </p>

              <div className="grid md:grid-cols-2 gap-8 mt-12">
                <div className="bg-card p-6 rounded-lg border border-primary/20">
                  <h3 className="text-2xl font-bold text-primary mb-4">Social Justice</h3>
                  <p className="text-muted-foreground">
                    Leveraging decentralized technology to create equal opportunities for all, breaking down traditional
                    barriers and empowering marginalized communities.
                  </p>
                </div>

                <div className="bg-card p-6 rounded-lg border border-secondary/20">
                  <h3 className="text-2xl font-bold text-secondary mb-4">Economic Equality</h3>
                  <p className="text-muted-foreground">
                    Building a financial system that serves everyone, not just the privileged few. AMBEDKAR token
                    represents democratic access to wealth creation.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
