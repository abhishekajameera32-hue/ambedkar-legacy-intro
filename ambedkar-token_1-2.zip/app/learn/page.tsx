import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"

export default function LearnPage() {
  const learningResources = [
    {
      title: "Dr. B.R. Ambedkar's Legacy",
      description: "Learn about the life and teachings of Dr. Ambedkar, the architect of India's Constitution.",
      topics: ["Constitutional Law", "Social Justice", "Educational Reform", "Religious Philosophy"],
    },
    {
      title: "Blockchain & Social Impact",
      description: "Understand how blockchain technology can drive social change and economic equality.",
      topics: ["Decentralized Finance", "Digital Identity", "Financial Inclusion", "Governance"],
    },
    {
      title: "AMBEDKAR Token Ecosystem",
      description: "Deep dive into our tokenomics, governance model, and community initiatives.",
      topics: ["Token Utility", "Governance Rights", "Community Funding", "Staking Rewards"],
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-8">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Learn
              </span>
            </h1>

            <p className="text-xl text-muted-foreground text-center mb-12">
              Education is the most powerful weapon which you can use to change the world.
            </p>

            <div className="space-y-8 mt-12">
              {learningResources.map((resource, index) => (
                <Card key={index} className="p-6 bg-card/50 backdrop-blur-sm border-primary/20">
                  <h3 className="text-2xl font-bold text-foreground mb-4">{resource.title}</h3>
                  <p className="text-muted-foreground mb-6">{resource.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {resource.topics.map((topic, topicIndex) => (
                      <span
                        key={topicIndex}
                        className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm font-semibold"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
