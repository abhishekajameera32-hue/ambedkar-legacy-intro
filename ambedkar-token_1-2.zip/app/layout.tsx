import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Suspense } from "react"
import "./globals.css"

export const metadata: Metadata = {
  title: "AMBEDKAR Token ($AMB) - Revolutionize Equality Through Blockchain",
  description:
    "Join Dr. Ambedkar's digital revolution for social and economic justice on Solana. Buy $AMB token on Pump.fun and be part of the equality movement.",
  generator: "v0.app",
  keywords: ["AMBEDKAR", "AMB", "token", "blockchain", "Solana", "social justice", "equality", "Web3", "pump.fun"],
  authors: [{ name: "AMBEDKAR Token Team" }],
  openGraph: {
    title: "AMBEDKAR Token ($AMB) - Revolutionize Equality Through Blockchain",
    description:
      "Join Dr. Ambedkar's digital revolution for social and economic justice on Solana. Buy $AMB on Pump.fun",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable} antialiased`}>
        <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
      </body>
    </html>
  )
}
