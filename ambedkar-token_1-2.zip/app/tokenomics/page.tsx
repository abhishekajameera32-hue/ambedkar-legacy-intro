import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"

export default function TokenomicsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-8">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Tokenomics
              </span>
            </h1>

            <div className="grid md:grid-cols-2 gap-8 mt-12">
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-primary/20">
                <h3 className="text-2xl font-bold text-primary mb-4">Total Supply</h3>
                <p className="text-3xl font-bold text-foreground mb-2">1,000,000,000 AMB</p>
                <p className="text-muted-foreground">Fixed supply with no inflation</p>
              </Card>

              <Card className="p-6 bg-card/50 backdrop-blur-sm border-secondary/20">
                <h3 className="text-2xl font-bold text-secondary mb-4">Distribution</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Public Sale</span>
                    <span className="font-bold">70%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Community Fund</span>
                    <span className="font-bold">20%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Development</span>
                    <span className="font-bold">10%</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
