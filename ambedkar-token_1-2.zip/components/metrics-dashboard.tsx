"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PriceChart } from "@/components/price-chart"
import { VolumeChart } from "@/components/volume-chart"
import { HoldersChart } from "@/components/holders-chart"

interface MetricsData {
  price: number
  priceChange24h: number
  volume24h: number
  volumeChange24h: number
  marketCap: number
  marketCapChange24h: number
  holders: number
  holdersChange24h: number
  totalSupply: number
  circulatingSupply: number
  bondingCurveProgress: number
  liquidityPool: number
  transactions24h: number
  avgTransactionSize: number
}

interface PricePoint {
  timestamp: number
  price: number
  volume: number
}

export function MetricsDashboard() {
  const [metrics, setMetrics] = useState<MetricsData>({
    price: 0.0001,
    priceChange24h: 2.4,
    volume24h: 45000,
    volumeChange24h: 18.3,
    marketCap: 125000,
    marketCapChange24h: 5.7,
    holders: 1247,
    holdersChange24h: 12,
    totalSupply: 1000000000,
    circulatingSupply: 670000000,
    bondingCurveProgress: 67,
    liquidityPool: 85000,
    transactions24h: 342,
    avgTransactionSize: 131.58,
  })

  const [priceHistory, setPriceHistory] = useState<PricePoint[]>([])
  const [isLive, setIsLive] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Initialize price history
  useEffect(() => {
    const now = Date.now()
    const initialHistory: PricePoint[] = []

    for (let i = 23; i >= 0; i--) {
      const timestamp = now - i * 60 * 60 * 1000 // 24 hours of hourly data
      const basePrice = 0.0001
      const variation = (Math.random() - 0.5) * 0.00002
      const price = Math.max(0.00001, basePrice + variation)
      const volume = Math.random() * 5000 + 1000

      initialHistory.push({ timestamp, price, volume })
    }

    setPriceHistory(initialHistory)
  }, [])

  // Real-time updates simulation
  useEffect(() => {
    if (!isLive) return

    const interval = setInterval(() => {
      // Update metrics
      setMetrics((prev) => ({
        ...prev,
        price: Math.max(0.00001, prev.price + (Math.random() - 0.5) * 0.00001),
        volume24h: Math.max(1000, prev.volume24h + (Math.random() - 0.5) * 500),
        marketCap: Math.max(10000, prev.marketCap + (Math.random() - 0.5) * 1000),
        holders: prev.holders + Math.floor(Math.random() * 3),
        transactions24h: prev.transactions24h + Math.floor(Math.random() * 2),
        bondingCurveProgress: Math.min(100, prev.bondingCurveProgress + Math.random() * 0.1),
      }))

      // Add new price point
      setPriceHistory((prev) => {
        const newPoint: PricePoint = {
          timestamp: Date.now(),
          price: metrics.price,
          volume: Math.random() * 2000 + 500,
        }
        return [...prev.slice(-23), newPoint] // Keep last 24 points
      })

      setLastUpdate(new Date())
    }, 3000)

    return () => clearInterval(interval)
  }, [isLive, metrics.price])

  const formatNumber = (num: number, decimals = 0) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toFixed(decimals)
  }

  const formatPrice = (price: number) => {
    return price.toFixed(6)
  }

  const formatPercentage = (percent: number) => {
    const sign = percent >= 0 ? "+" : ""
    return `${sign}${percent.toFixed(2)}%`
  }

  return (
    <section className="py-16 bg-gradient-to-br from-muted/50 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Real-time Analytics Dashboard</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Track AMBEDKAR token performance with live blockchain data and comprehensive metrics
          </p>
        </div>

        {/* Live Status Indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center space-x-4 bg-card/50 backdrop-blur-sm border border-primary/20 rounded-lg px-6 py-3">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isLive ? "bg-green-500 animate-pulse" : "bg-gray-400"}`}></div>
              <span className="text-sm font-semibold text-foreground">{isLive ? "Live Data" : "Paused"}</span>
            </div>
            <div className="text-xs text-muted-foreground">Last update: {lastUpdate.toLocaleTimeString()}</div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsLive(!isLive)}
              className="text-xs border-primary/20"
            >
              {isLive ? "Pause" : "Resume"}
            </Button>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
          <Card className="p-4 bg-card/50 backdrop-blur-sm border-primary/20">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Price</p>
              <p className="text-lg font-bold text-primary">${formatPrice(metrics.price)}</p>
              <p className={`text-xs ${metrics.priceChange24h >= 0 ? "text-green-500" : "text-red-500"}`}>
                {formatPercentage(metrics.priceChange24h)}
              </p>
            </div>
          </Card>

          <Card className="p-4 bg-card/50 backdrop-blur-sm border-secondary/20">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">24h Volume</p>
              <p className="text-lg font-bold text-secondary">${formatNumber(metrics.volume24h)}</p>
              <p className={`text-xs ${metrics.volumeChange24h >= 0 ? "text-green-500" : "text-red-500"}`}>
                {formatPercentage(metrics.volumeChange24h)}
              </p>
            </div>
          </Card>

          <Card className="p-4 bg-card/50 backdrop-blur-sm border-accent/20">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Market Cap</p>
              <p className="text-lg font-bold text-accent">${formatNumber(metrics.marketCap)}</p>
              <p className={`text-xs ${metrics.marketCapChange24h >= 0 ? "text-green-500" : "text-red-500"}`}>
                {formatPercentage(metrics.marketCapChange24h)}
              </p>
            </div>
          </Card>

          <Card className="p-4 bg-card/50 backdrop-blur-sm border-border">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Holders</p>
              <p className="text-lg font-bold text-foreground">{formatNumber(metrics.holders)}</p>
              <p className="text-xs text-green-500">+{metrics.holdersChange24h}</p>
            </div>
          </Card>

          <Card className="p-4 bg-card/50 backdrop-blur-sm border-border">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">24h Txns</p>
              <p className="text-lg font-bold text-foreground">{metrics.transactions24h}</p>
              <p className="text-xs text-muted-foreground">Avg: ${metrics.avgTransactionSize.toFixed(0)}</p>
            </div>
          </Card>

          <Card className="p-4 bg-card/50 backdrop-blur-sm border-border">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Bonding Curve</p>
              <p className="text-lg font-bold text-foreground">{metrics.bondingCurveProgress.toFixed(1)}%</p>
              <p className="text-xs text-accent">To DEX listing</p>
            </div>
          </Card>
        </div>

        {/* Charts Section */}
        <Tabs defaultValue="price" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="price">Price Chart</TabsTrigger>
            <TabsTrigger value="volume">Volume</TabsTrigger>
            <TabsTrigger value="holders">Holders Growth</TabsTrigger>
          </TabsList>

          <TabsContent value="price">
            <Card className="p-6 bg-card/50 backdrop-blur-sm border-primary/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Price History (24h)</h3>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>Current: ${formatPrice(metrics.price)}</span>
                  <span className={metrics.priceChange24h >= 0 ? "text-green-500" : "text-red-500"}>
                    ({formatPercentage(metrics.priceChange24h)})
                  </span>
                </div>
              </div>
              <PriceChart data={priceHistory} />
            </Card>
          </TabsContent>

          <TabsContent value="volume">
            <Card className="p-6 bg-card/50 backdrop-blur-sm border-secondary/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Trading Volume (24h)</h3>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>Total: ${formatNumber(metrics.volume24h)}</span>
                  <span className={metrics.volumeChange24h >= 0 ? "text-green-500" : "text-red-500"}>
                    ({formatPercentage(metrics.volumeChange24h)})
                  </span>
                </div>
              </div>
              <VolumeChart data={priceHistory} />
            </Card>
          </TabsContent>

          <TabsContent value="holders">
            <Card className="p-6 bg-card/50 backdrop-blur-sm border-accent/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Holder Growth</h3>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>Total: {formatNumber(metrics.holders)}</span>
                  <span className="text-green-500">(+{metrics.holdersChange24h} today)</span>
                </div>
              </div>
              <HoldersChart holders={metrics.holders} />
            </Card>
          </TabsContent>
        </Tabs>

        {/* Additional Metrics */}
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-primary/20">
            <h3 className="text-lg font-semibold text-foreground mb-4">Token Distribution</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Circulating Supply</span>
                  <span className="text-foreground">{formatNumber(metrics.circulatingSupply)} AMB</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full"
                    style={{ width: `${(metrics.circulatingSupply / metrics.totalSupply) * 100}%` }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Bonding Curve Progress</span>
                  <span className="text-foreground">{metrics.bondingCurveProgress.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-secondary to-accent h-2 rounded-full"
                    style={{ width: `${metrics.bondingCurveProgress}%` }}
                  ></div>
                </div>
              </div>
              <div className="pt-2 border-t border-border">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Supply:</span>
                  <span className="text-foreground font-semibold">{formatNumber(metrics.totalSupply)} AMB</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Liquidity Pool:</span>
                  <span className="text-foreground font-semibold">${formatNumber(metrics.liquidityPool)}</span>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card/50 backdrop-blur-sm border-accent/20">
            <h3 className="text-lg font-semibold text-foreground mb-4">Network Activity</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">24h Transactions</span>
                <span className="text-foreground font-semibold">{metrics.transactions24h}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Avg Transaction Size</span>
                <span className="text-foreground font-semibold">${metrics.avgTransactionSize.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Active Traders (24h)</span>
                <span className="text-foreground font-semibold">{Math.floor(metrics.transactions24h * 0.7)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Network</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-foreground font-semibold">Solana</span>
                </div>
              </div>
              <div className="pt-2 border-t border-border">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground mb-1">Next milestone</p>
                  <p className="text-sm font-semibold text-accent">
                    {(100 - metrics.bondingCurveProgress).toFixed(1)}% to DEX listing
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
