"use client"

import { useEffect, useRef } from "react"

interface PricePoint {
  timestamp: number
  price: number
  volume: number
}

interface VolumeChartProps {
  data: PricePoint[]
}

export function VolumeChart({ data }: VolumeChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || data.length === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * window.devicePixelRatio
    canvas.height = rect.height * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    const width = rect.width
    const height = rect.height
    const padding = 40

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Find max volume
    const volumes = data.map((d) => d.volume)
    const maxVolume = Math.max(...volumes)

    // Draw grid lines
    ctx.strokeStyle = "rgba(211, 47, 47, 0.1)"
    ctx.lineWidth = 1

    // Horizontal grid lines
    for (let i = 0; i <= 4; i++) {
      const y = padding + (i * (height - 2 * padding)) / 4
      ctx.beginPath()
      ctx.moveTo(padding, y)
      ctx.lineTo(width - padding, y)
      ctx.stroke()
    }

    // Draw volume bars
    const barWidth = ((width - 2 * padding) / data.length) * 0.8

    data.forEach((point, index) => {
      const x = padding + (index * (width - 2 * padding)) / data.length
      const barHeight = (point.volume / maxVolume) * (height - 2 * padding)
      const y = height - padding - barHeight

      // Create gradient
      const gradient = ctx.createLinearGradient(0, y, 0, height - padding)
      gradient.addColorStop(0, "rgba(211, 47, 47, 0.8)")
      gradient.addColorStop(1, "rgba(211, 47, 47, 0.3)")

      ctx.fillStyle = gradient
      ctx.fillRect(x, y, barWidth, barHeight)
    })

    // Draw labels
    ctx.fillStyle = "rgba(107, 114, 128, 1)"
    ctx.font = "12px sans-serif"

    // Volume labels (Y-axis)
    for (let i = 0; i <= 4; i++) {
      const volume = (i * maxVolume) / 4
      const y = height - padding - (i * (height - 2 * padding)) / 4
      ctx.textAlign = "right"
      ctx.fillText(`${(volume / 1000).toFixed(1)}K`, padding - 5, y + 4)
    }

    // Time labels (X-axis)
    ctx.textAlign = "center"
    for (let i = 0; i < data.length; i += Math.ceil(data.length / 6)) {
      const x = padding + (i * (width - 2 * padding)) / data.length + barWidth / 2
      const time = new Date(data[i].timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      ctx.fillText(time, x, height - padding + 20)
    }
  }, [data])

  return (
    <div className="w-full h-64 relative">
      <canvas ref={canvasRef} className="w-full h-full" style={{ width: "100%", height: "100%" }} />
    </div>
  )
}
