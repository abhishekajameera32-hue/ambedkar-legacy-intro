"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Text3D, Environment, Float, Sparkles } from "@react-three/drei"
import { Suspense } from "react"

interface CinematicIntroProps {
  onComplete: () => void
  onSkip: () => void
}

function AmbedkarFigure3D() {
  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <group>
        {/* Main figure silhouette */}
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[2, 4, 0.5]} />
          <meshStandardMaterial color="#d97706" metalness={0.3} roughness={0.4} />
        </mesh>

        {/* Head */}
        <mesh position={[0, 2.5, 0]}>
          <sphereGeometry args={[0.8, 32, 32]} />
          <meshStandardMaterial color="#d97706" metalness={0.2} roughness={0.3} />
        </mesh>

        {/* Glasses */}
        <mesh position={[0, 2.7, 0.4]}>
          <boxGeometry args={[1.2, 0.3, 0.1]} />
          <meshStandardMaterial color="#ffffff" transparent opacity={0.8} />
        </mesh>

        {/* Coin in hand */}
        <Float speed={4} rotationIntensity={1} floatIntensity={1}>
          <mesh position={[1.5, 1, 1]}>
            <cylinderGeometry args={[0.5, 0.5, 0.1, 32]} />
            <meshStandardMaterial color="#f59e0b" metalness={0.8} roughness={0.1} />
          </mesh>

          {/* "A" on coin */}
          <Text3D position={[1.5, 1, 1.1]} font="/fonts/helvetiker_bold.typeface.json" size={0.3} height={0.05}>
            A
            <meshStandardMaterial color="#000000" />
          </Text3D>
        </Float>

        {/* Constitutional aura */}
        <Sparkles count={50} scale={8} size={3} speed={0.5} color="#d97706" />
      </group>
    </Float>
  )
}

function LawBackdrop3D() {
  return (
    <group>
      {/* Scales of justice */}
      <Float speed={1} rotationIntensity={0.2} floatIntensity={0.3}>
        <mesh position={[-4, 2, -2]}>
          <cylinderGeometry args={[0.1, 0.1, 3, 8]} />
          <meshStandardMaterial color="#dc2626" metalness={0.5} roughness={0.3} />
        </mesh>

        {/* Scale pans */}
        <mesh position={[-4.8, 3, -2]}>
          <cylinderGeometry args={[0.5, 0.5, 0.1, 16]} />
          <meshStandardMaterial color="#d97706" metalness={0.7} roughness={0.2} />
        </mesh>
        <mesh position={[-3.2, 3, -2]}>
          <cylinderGeometry args={[0.5, 0.5, 0.1, 16]} />
          <meshStandardMaterial color="#d97706" metalness={0.7} roughness={0.2} />
        </mesh>
      </Float>

      {/* Constitutional pillars */}
      {[-6, -2, 2, 6].map((x, i) => (
        <mesh key={i} position={[x, 0, -4]}>
          <cylinderGeometry args={[0.3, 0.3, 6, 8]} />
          <meshStandardMaterial color="#374151" metalness={0.1} roughness={0.8} />
        </mesh>
      ))}

      {/* Floating law symbols */}
      <Text3D position={[4, 3, -1]} font="/fonts/helvetiker_regular.typeface.json" size={0.5} height={0.1}>
        §
        <meshStandardMaterial color="#dc2626" />
      </Text3D>
    </group>
  )
}

export function CinematicIntro({ onComplete, onSkip }: CinematicIntroProps) {
  const [currentPhase, setCurrentPhase] = useState(0)
  const [showSkipButton, setShowSkipButton] = useState(false)
  const [speechText, setSpeechText] = useState("")

  const ambedkarSpeech =
    "My fellow citizens, through the power of blockchain technology, we shall create a society where justice, liberty, equality, and fraternity are not mere constitutional words, but living digital realities. The AMBEDKAR token represents our collective fight against inequality. Join this revolution!"

  const speechWords = ambedkarSpeech.split(" ")

  useEffect(() => {
    console.log("[v0] 3D Cinematic intro mounted")

    const skipTimer = setTimeout(() => {
      setShowSkipButton(true)
    }, 2000)

    const startTimer = setTimeout(() => {
      setCurrentPhase(1)
    }, 500)

    return () => {
      clearTimeout(skipTimer)
      clearTimeout(startTimer)
    }
  }, [])

  useEffect(() => {
    if (currentPhase === 0) return

    console.log(`[v0] 3D Phase ${currentPhase} started`)
    const phaseTimers: NodeJS.Timeout[] = []

    // Phase 1: 3D Ambedkar appears with speech (6s)
    if (currentPhase === 1) {
      phaseTimers.push(setTimeout(() => setCurrentPhase(2), 6000))
    }
    // Phase 2: Constitutional transformation (5s)
    else if (currentPhase === 2) {
      phaseTimers.push(setTimeout(() => setCurrentPhase(3), 5000))
    }
    // Phase 3: Token revolution call (4s)
    else if (currentPhase === 3) {
      phaseTimers.push(
        setTimeout(() => {
          console.log("[v0] 3D Intro completing")
          onComplete()
        }, 4000),
      )
    }

    return () => {
      phaseTimers.forEach(clearTimeout)
    }
  }, [currentPhase, onComplete])

  useEffect(() => {
    if (currentPhase === 1) {
      let wordIndex = 0
      setSpeechText("")

      const speechInterval = setInterval(() => {
        if (wordIndex < speechWords.length) {
          setSpeechText(speechWords.slice(0, wordIndex + 1).join(" "))
          wordIndex++
        } else {
          clearInterval(speechInterval)
        }
      }, 120)

      return () => clearInterval(speechInterval)
    }
  }, [currentPhase, speechWords])

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-slate-900 via-slate-800 to-black flex items-center justify-center overflow-hidden">
      {/* Skip Button */}
      {showSkipButton && (
        <Button
          onClick={onSkip}
          variant="outline"
          className="absolute top-8 right-8 z-10 bg-black/50 border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
        >
          Skip Intro
        </Button>
      )}

      {/* Phase 1: 3D Ambedkar Appears with Speech (0-6s) */}
      {currentPhase === 1 && (
        <div className="relative w-full h-full">
          {/* 3D Scene */}
          <div className="absolute inset-0">
            <Canvas camera={{ position: [0, 2, 8], fov: 60 }}>
              <Suspense fallback={null}>
                <Environment preset="sunset" />
                <ambientLight intensity={0.3} />
                <directionalLight position={[10, 10, 5]} intensity={1} color="#d97706" />
                <pointLight position={[-10, -10, -5]} intensity={0.5} color="#dc2626" />

                <AmbedkarFigure3D />
                <LawBackdrop3D />

                <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
              </Suspense>
            </Canvas>
          </div>

          {/* Speech overlay */}
          <div className="absolute bottom-1/4 left-1/2 transform -translate-x-1/2 w-full max-w-4xl px-8 z-10">
            <div className="bg-black/80 backdrop-blur-sm rounded-lg p-6 border border-primary/30 animate-constitution-unfold">
              <p className="text-primary-foreground text-xl md:text-2xl leading-relaxed font-medium text-center min-h-[120px] flex items-center justify-center">
                {speechText}
                <span className="animate-pulse ml-1 text-primary">|</span>
              </p>
            </div>
          </div>

          {/* Law particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {["Justice", "Liberty", "Equality", "Fraternity", "Constitution", "§", "⚖", "📜"].map((symbol, i) => (
              <div
                key={symbol}
                className="absolute text-primary/20 text-lg font-bold animate-law-particles"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${i * 0.8}s`,
                }}
              >
                {symbol}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Phase 2: Constitutional Transformation (6-11s) */}
      {currentPhase === 2 && (
        <div className="text-center relative w-full h-full flex items-center justify-center bg-law-texture">
          <div className="absolute inset-0 bg-gradient-radial opacity-80"></div>

          {/* Constitutional document unfolding */}
          <div className="relative z-10 animate-constitution-unfold">
            <div className="w-80 h-96 mx-auto bg-gradient-to-b from-amber-50 to-amber-100 rounded-lg shadow-2xl border-4 border-primary relative overflow-hidden animate-justice-glow">
              {/* Constitutional text lines */}
              <div className="p-8 space-y-4">
                {["WE, THE PEOPLE", "OF INDIA", "JUSTICE", "LIBERTY", "EQUALITY", "FRATERNITY"].map((text, i) => (
                  <div
                    key={text}
                    className="text-slate-800 font-bold text-lg animate-fade-in-up"
                    style={{ animationDelay: `${i * 0.3}s` }}
                  >
                    {text}
                  </div>
                ))}
              </div>

              {/* Digital transformation effect */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-1 h-1 bg-primary rounded-full animate-ping"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      animationDelay: `${i * 0.1}s`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Transformation text */}
          <div className="absolute bottom-1/3 left-1/2 transform -translate-x-1/2 z-10">
            <h2 className="text-4xl md:text-6xl font-bold text-primary-foreground mb-4">
              <span className="inline-block animate-bounce text-primary">DIGITAL</span>{" "}
              <span className="inline-block animate-bounce text-secondary" style={{ animationDelay: "0.5s" }}>
                CONSTITUTION
              </span>
            </h2>
            <p className="text-xl text-primary-foreground/80 animate-fade-in-up" style={{ animationDelay: "1s" }}>
              Powered by Blockchain Technology
            </p>
          </div>
        </div>
      )}

      {/* Phase 3: Token Revolution Call (11-15s) */}
      {currentPhase === 3 && (
        <div className="text-center relative w-full h-full flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-black to-secondary/20"></div>

          {/* 3D Token formation */}
          <div className="absolute inset-0">
            <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
              <Suspense fallback={null}>
                <Environment preset="city" />
                <ambientLight intensity={0.4} />
                <pointLight position={[10, 10, 10]} intensity={1} color="#d97706" />

                <Float speed={3} rotationIntensity={1} floatIntensity={0.5}>
                  <mesh>
                    <cylinderGeometry args={[2, 2, 0.3, 32]} />
                    <meshStandardMaterial color="#d97706" metalness={0.8} roughness={0.1} />
                  </mesh>

                  <Text3D position={[-0.5, 0, 0.2]} font="/fonts/helvetiker_bold.typeface.json" size={1.5} height={0.1}>
                    A
                    <meshStandardMaterial color="#000000" />
                  </Text3D>

                  <Sparkles count={100} scale={6} size={4} speed={1} color="#f59e0b" />
                </Float>

                <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={2} />
              </Suspense>
            </Canvas>
          </div>

          {/* Final call to action overlay */}
          <div className="relative z-10 bg-black/60 backdrop-blur-sm rounded-2xl p-8 border border-primary/30">
            <h1 className="text-5xl md:text-7xl font-bold text-primary mb-4">
              <span className="inline-block animate-bounce">JOIN</span>{" "}
              <span className="inline-block animate-bounce" style={{ animationDelay: "0.3s" }}>
                THE
              </span>
            </h1>
            <h1 className="text-5xl md:text-7xl font-bold text-primary-foreground mb-6">
              <span className="inline-block animate-bounce" style={{ animationDelay: "0.6s" }}>
                REVOLUTION
              </span>
            </h1>

            <h2
              className="text-3xl md:text-4xl font-bold text-primary mb-4 animate-fade-in-up"
              style={{ animationDelay: "1s" }}
            >
              AMBEDKAR TOKEN
            </h2>
            <h3
              className="text-2xl md:text-3xl font-bold text-secondary mb-6 animate-fade-in-up"
              style={{ animationDelay: "1.2s" }}
            >
              $AMB
            </h3>

            <div className="mt-8 animate-fade-in-up" style={{ animationDelay: "1.5s" }}>
              <p className="text-primary-foreground/90 text-xl mb-2">The future of digital equality</p>
              <p className="text-primary text-lg">Powered by Solana Blockchain</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
