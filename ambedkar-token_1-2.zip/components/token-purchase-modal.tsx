"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useWallet } from "@/lib/wallet-context"

interface TokenPurchaseModalProps {
  isOpen: boolean
  onClose: () => void
}

interface PurchaseState {
  solAmount: string
  ambAmount: string
  slippage: number
  networkFee: number
  totalCost: number
}

type PurchaseStep = "input" | "confirmation" | "approval" | "processing" | "success" | "error"

export function TokenPurchaseModal({ isOpen, onClose }: TokenPurchaseModalProps) {
  const { isConnected, balance, publicKey, signTransaction } = useWallet()
  const [currentStep, setCurrentStep] = useState<PurchaseStep>("input")
  const [purchaseState, setPurchaseState] = useState<PurchaseState>({
    solAmount: "5.25",
    ambAmount: "52500",
    slippage: 1.0,
    networkFee: 0.0005,
    totalCost: 5.2505,
  })
  const [transactionId, setTransactionId] = useState("")
  const [errorMessage, setErrorMessage] = useState("")
  const [isCalculating, setIsCalculating] = useState(false)

  // Bonding curve parameters
  const [bondingCurveData] = useState({
    currentPrice: 0.0001,
    priceImpact: 0.02,
    liquidityPool: 125000,
    totalSupply: 1000000000,
    circulatingSupply: 670000000,
  })

  // Calculate AMB amount based on SOL input with bonding curve
  useEffect(() => {
    if (purchaseState.solAmount && !isNaN(Number(purchaseState.solAmount))) {
      setIsCalculating(true)
      const debounceTimer = setTimeout(() => {
        const solValue = Number(purchaseState.solAmount)
        const baseRate = 10000 // 1 SOL = 10,000 AMB base rate
        const priceImpact = Math.min(solValue * 0.001, 0.05) // Max 5% price impact
        const adjustedRate = baseRate * (1 - priceImpact)
        const ambValue = Math.floor(solValue * adjustedRate)

        setPurchaseState((prev) => ({
          ...prev,
          ambAmount: ambValue.toString(),
          totalCost: solValue + prev.networkFee,
        }))
        setIsCalculating(false)
      }, 500)

      return () => clearTimeout(debounceTimer)
    }
  }, [purchaseState.solAmount])

  const handleSolAmountChange = (value: string) => {
    // Only allow valid number input
    if (value === "" || /^\d*\.?\d*$/.test(value)) {
      setPurchaseState((prev) => ({ ...prev, solAmount: value }))
    }
  }

  const handleMaxClick = () => {
    const maxAmount = Math.max(0, balance - purchaseState.networkFee - 0.001) // Keep some SOL for future transactions
    setPurchaseState((prev) => ({ ...prev, solAmount: maxAmount.toFixed(4) }))
  }

  const handleSlippageChange = (slippage: number) => {
    setPurchaseState((prev) => ({ ...prev, slippage }))
  }

  const handleConfirmPurchase = () => {
    if (!isConnected) {
      setErrorMessage("Please connect your wallet first")
      setCurrentStep("error")
      return
    }

    if (Number(purchaseState.solAmount) > balance) {
      setErrorMessage("Insufficient SOL balance")
      setCurrentStep("error")
      return
    }

    if (Number(purchaseState.solAmount) < 0.001) {
      setErrorMessage("Minimum purchase amount is 0.001 SOL")
      setCurrentStep("error")
      return
    }

    setCurrentStep("confirmation")
  }

  const handleProceedWithPurchase = async () => {
    setCurrentStep("approval")

    try {
      // Simulate wallet approval
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setCurrentStep("processing")

      // Simulate transaction signing and broadcasting
      const mockTransaction = {
        from: publicKey,
        to: "AMB_TOKEN_CONTRACT",
        amount: purchaseState.solAmount,
        type: "token_purchase",
      }

      const signature = await signTransaction(mockTransaction)
      setTransactionId(signature.slice(0, 16) + "..." + signature.slice(-16))

      // Simulate blockchain confirmation
      await new Promise((resolve) => setTimeout(resolve, 3000))

      setCurrentStep("success")
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Transaction failed")
      setCurrentStep("error")
    }
  }

  const handleClose = () => {
    if (currentStep !== "processing" && currentStep !== "approval") {
      setCurrentStep("input")
      setErrorMessage("")
      onClose()
    }
  }

  const handleRetry = () => {
    setCurrentStep("input")
    setErrorMessage("")
  }

  const isValidPurchase = () => {
    const solValue = Number(purchaseState.solAmount)
    return solValue > 0 && solValue <= balance && solValue >= 0.001
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-card border-primary/20">
        {/* Input Step */}
        {currentStep === "input" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-bold text-foreground">Buy AMBEDKAR Tokens</DialogTitle>
              <DialogDescription className="text-center text-muted-foreground">
                Join the revolution with $AMB tokens on Solana
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {/* Purchase Interface */}
              <Card className="p-4 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
                <div className="space-y-4">
                  {/* You Pay Section */}
                  <div>
                    <label className="text-sm font-semibold text-foreground mb-2 block">You Pay</label>
                    <div className="relative">
                      <Input
                        type="text"
                        value={purchaseState.solAmount}
                        onChange={(e) => handleSolAmountChange(e.target.value)}
                        className="text-lg font-semibold pr-20 bg-background border-primary/20"
                        placeholder="0.00"
                      />
                      <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleMaxClick}
                          className="text-xs border-primary/20 text-primary hover:bg-primary/10 bg-transparent"
                        >
                          MAX
                        </Button>
                        <span className="text-sm font-semibold text-foreground">SOL</span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Balance: {balance.toFixed(4)} SOL</p>
                  </div>

                  {/* Conversion Arrow */}
                  <div className="flex justify-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l4.293-4.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                  </div>

                  {/* You Receive Section */}
                  <div>
                    <label className="text-sm font-semibold text-foreground mb-2 block">You Receive</label>
                    <div className="relative">
                      <Input
                        type="text"
                        value={
                          isCalculating ? "Calculating..." : `≈ ${Number(purchaseState.ambAmount).toLocaleString()}`
                        }
                        readOnly
                        className="text-lg font-semibold pr-16 bg-muted border-primary/20"
                      />
                      <div className="absolute right-2 top-1/2 transform -translate-y-1/2">
                        <span className="text-sm font-semibold text-foreground">AMB</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Transaction Details */}
              <Card className="p-4 bg-card/50 border-border">
                <h3 className="font-semibold text-foreground mb-3">Transaction Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Price:</span>
                    <span className="text-foreground">
                      1 SOL = {Number(purchaseState.ambAmount) / Number(purchaseState.solAmount || 1) || 10000} AMB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Price Impact:</span>
                    <span className="text-green-500">~{(Number(purchaseState.solAmount) * 0.1).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Slippage Tolerance:</span>
                    <div className="flex items-center space-x-2">
                      {[0.5, 1.0, 3.0].map((value) => (
                        <Button
                          key={value}
                          size="sm"
                          variant={purchaseState.slippage === value ? "default" : "outline"}
                          onClick={() => handleSlippageChange(value)}
                          className="text-xs px-2 py-1 h-6"
                        >
                          {value}%
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Network Fee:</span>
                    <span className="text-foreground">≈ {purchaseState.networkFee} SOL</span>
                  </div>
                  <div className="border-t border-border pt-2 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span className="text-foreground">Total Cost:</span>
                      <span className="text-foreground">{purchaseState.totalCost.toFixed(4)} SOL</span>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Purchase Button */}
              <Button
                onClick={handleConfirmPurchase}
                disabled={!isValidPurchase() || isCalculating}
                className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-semibold py-3 text-lg"
              >
                {!isConnected
                  ? "Connect Wallet First"
                  : !isValidPurchase()
                    ? "Enter Valid Amount"
                    : isCalculating
                      ? "Calculating..."
                      : "Buy AMBEDKAR"}
              </Button>
            </div>
          </>
        )}

        {/* Confirmation Step */}
        {currentStep === "confirmation" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-bold text-foreground">Confirm Purchase</DialogTitle>
              <DialogDescription className="text-center text-muted-foreground">
                Review your transaction details
              </DialogDescription>
            </DialogHeader>

            <Card className="p-6 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
              <div className="text-center space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">You will pay</p>
                  <p className="text-2xl font-bold text-foreground">{purchaseState.solAmount} SOL</p>
                </div>
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mx-auto">
                  <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l4.293-4.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">To receive approximately</p>
                  <p className="text-2xl font-bold text-primary">
                    {Number(purchaseState.ambAmount).toLocaleString()} AMB
                  </p>
                </div>
                <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
                  Network fee: ~{purchaseState.networkFee} SOL
                </div>
              </div>
            </Card>

            <div className="flex space-x-3">
              <Button onClick={() => setCurrentStep("input")} variant="outline" className="flex-1 border-border">
                Go Back
              </Button>
              <Button
                onClick={handleProceedWithPurchase}
                className="flex-1 bg-secondary hover:bg-secondary/90 text-secondary-foreground"
              >
                Confirm Purchase
              </Button>
            </div>
          </>
        )}

        {/* Approval Step */}
        {currentStep === "approval" && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <span className="text-2xl">👻</span>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Approve Transaction</h3>
            <p className="text-muted-foreground">Please approve the transaction in your wallet</p>
            <div className="mt-4 p-3 bg-accent/10 rounded-lg">
              <p className="text-sm text-accent">Check your wallet extension for the approval request</p>
            </div>
          </div>
        )}

        {/* Processing Step */}
        {currentStep === "processing" && (
          <div className="text-center py-8">
            <div className="relative w-16 h-16 mx-auto mb-4">
              <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-t-primary rounded-full animate-spin"></div>
              <div className="absolute inset-2 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-lg">⚡</span>
              </div>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Broadcasting Transaction...</h3>
            <p className="text-muted-foreground">Your transaction is being processed on Solana</p>
            <div className="mt-4 p-3 bg-primary/10 rounded-lg">
              <p className="text-sm text-primary">This usually takes 10-30 seconds</p>
            </div>
          </div>
        )}

        {/* Success Step */}
        {currentStep === "success" && (
          <>
            <div className="text-center py-8">
              {/* Confetti effect */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 bg-primary rounded-full animate-bounce"
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      animationDelay: `${i * 0.1}s`,
                      animationDuration: "2s",
                    }}
                  ></div>
                ))}
              </div>

              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <span className="text-2xl text-green-500">🎉</span>
              </div>
              <h3 className="text-lg font-semibold text-green-500 mb-2">Revolution Joined!</h3>
              <p className="text-foreground font-semibold mb-1">
                You successfully purchased {Number(purchaseState.ambAmount).toLocaleString()} AMB!
              </p>
              <p className="text-sm text-muted-foreground mb-4">Transaction ID: {transactionId}</p>

              <div className="space-y-3">
                <Button
                  onClick={() => window.open(`https://solscan.io/tx/${transactionId}`, "_blank")}
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary/10"
                >
                  View on Solscan
                </Button>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => setCurrentStep("input")}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Buy More
                  </Button>
                  <Button
                    onClick={() =>
                      window.open(
                        "https://twitter.com/intent/tweet?text=I%20just%20joined%20the%20AMBEDKAR%20revolution!",
                        "_blank",
                      )
                    }
                    variant="outline"
                    className="flex-1 border-accent text-accent hover:bg-accent/10"
                  >
                    Share on Twitter
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Error Step */}
        {currentStep === "error" && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl text-red-500">❌</span>
            </div>
            <h3 className="text-lg font-semibold text-red-500 mb-2">Transaction Failed</h3>
            <p className="text-muted-foreground mb-4">{errorMessage}</p>
            <div className="space-y-2">
              <Button onClick={handleRetry} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                Try Again
              </Button>
              <Button onClick={handleClose} variant="outline" className="w-full bg-transparent">
                Close
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
