"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AmbedkarModel3D } from "@/components/ambedkar-model-3d"

export function HeroSection() {
  const [metrics, setMetrics] = useState({
    price: 0.0001,
    holders: 1247,
    marketCap: 125000,
    volume24h: 45000,
  })

  const [currentQuote, setCurrentQuote] = useState(0)
  const quotes = [
    "Be Educated, Be Organised, Be Agitated",
    "Cultivation of mind should be the ultimate aim",
    "Religion is for man and not man for religion",
    "Lost rights are never regained by appeals to the conscience",
    "Political tyranny is nothing compared to social tyranny",
  ]

  // Simulate live metrics updates with smooth counting animation
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics((prev) => ({
        price: Math.max(0.00001, prev.price + (Math.random() - 0.5) * 0.00001),
        holders: prev.holders + Math.floor(Math.random() * 3),
        marketCap: Math.max(10000, prev.marketCap + (Math.random() - 0.5) * 1000),
        volume24h: Math.max(1000, prev.volume24h + (Math.random() - 0.5) * 500),
      }))
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  // Rotate quotes every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length)
    }, 4000)

    return () => clearInterval(interval)
  }, [quotes.length])

  const handleBuyClick = () => {
    const pumpFunUrl = "https://pump.fun/coin/AMB"
    window.open(pumpFunUrl, "_blank", "noopener,noreferrer")
  }

  const handleJoinRevolution = () => {
    const communitySection = document.getElementById("community")
    if (communitySection) {
      communitySection.scrollIntoView({ behavior: "smooth" })
    } else {
      // Fallback to Twitter/X
      window.open("https://twitter.com/ambedkartoken", "_blank", "noopener,noreferrer")
    }
  }

  return (
    <section className="min-h-screen pt-20 bg-gradient-to-br from-background via-background to-muted relative overflow-hidden">
      {/* Subtle blockchain grid background with parallax effect */}
      <div className="absolute inset-0 opacity-5">
        <div className="grid grid-cols-20 grid-rows-20 h-full w-full">
          {Array.from({ length: 400 }).map((_, i) => (
            <div
              key={i}
              className="border border-primary/20 animate-pulse"
              style={{
                animationDelay: `${i * 10}ms`,
                animationDuration: "3s",
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-primary/30 rounded-full animate-bounce"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content (60% width) */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-balance leading-tight">
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent animate-fade-in-up">
                  REVOLUTIONIZE
                </span>
                <br />
                <span className="text-foreground animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                  EQUALITY
                </span>
                <br />
                <span className="text-muted-foreground animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
                  THROUGH BLOCKCHAIN
                </span>
              </h1>

              <p
                className="text-xl text-muted-foreground text-pretty max-w-2xl animate-fade-in-up"
                style={{ animationDelay: "0.6s" }}
              >
                Join Dr. Ambedkar's digital revolution for social and economic justice on Solana. The future of equality
                is powered by Web3 technology and decentralized governance.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
              <Button
                size="lg"
                onClick={handleJoinRevolution}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 py-4 text-lg animate-pulse-gold transform hover:scale-105 transition-all duration-300"
              >
                <span className="mr-2">🚀</span>
                Join The Revolution
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={handleBuyClick}
                className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground font-semibold px-8 py-4 text-lg bg-transparent transform hover:scale-105 transition-all duration-300"
              >
                <span className="mr-2">💎</span>
                Buy $AMB on Pump.fun
              </Button>
            </div>

            {/* Live Metrics Dashboard */}
            <Card
              className="p-6 bg-card/50 backdrop-blur-sm border-primary/20 animate-fade-in-up"
              style={{ animationDelay: "1s" }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Live Metrics</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-muted-foreground">Live</span>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-muted-foreground mb-1">$AMB Price</p>
                  <p className="text-lg font-bold text-primary">${metrics.price.toFixed(6)}</p>
                  <p className="text-xs text-green-500">+2.4%</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-secondary/10 border border-secondary/20">
                  <p className="text-sm text-muted-foreground mb-1">Holders</p>
                  <p className="text-lg font-bold text-secondary">{metrics.holders.toLocaleString()}</p>
                  <p className="text-xs text-green-500">+12</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-accent/10 border border-accent/20">
                  <p className="text-sm text-muted-foreground mb-1">Market Cap</p>
                  <p className="text-lg font-bold text-accent">${metrics.marketCap.toLocaleString()}</p>
                  <p className="text-xs text-green-500">+5.7%</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">24h Vol</p>
                  <p className="text-lg font-bold text-foreground">${metrics.volume24h.toLocaleString()}</p>
                  <p className="text-xs text-green-500">+18.3%</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Hero Visual (40% width) */}
          <div className="relative animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <div className="w-full max-w-md mx-auto">
              {/* 3D Model Container */}
              <div className="relative w-80 h-80 mx-auto">
                <AmbedkarModel3D />

                {/* Rotating quotes around the model */}
                <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 w-full text-center">
                  <div className="relative h-8 overflow-hidden">
                    {quotes.map((quote, index) => (
                      <p
                        key={index}
                        className={`absolute inset-0 text-sm font-semibold transition-all duration-500 ${
                          index === currentQuote
                            ? "opacity-100 translate-y-0 text-primary"
                            : "opacity-0 translate-y-4 text-muted-foreground"
                        }`}
                      >
                        "{quote}"
                      </p>
                    ))}
                  </div>
                </div>

                {/* Social justice symbols floating around */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-4 right-4 text-2xl animate-bounce" style={{ animationDelay: "0s" }}>
                    ⚖️
                  </div>
                  <div className="absolute bottom-4 left-4 text-2xl animate-bounce" style={{ animationDelay: "1s" }}>
                    📚
                  </div>
                  <div className="absolute top-1/2 right-0 text-2xl animate-bounce" style={{ animationDelay: "2s" }}>
                    🤝
                  </div>
                  <div className="absolute top-1/2 left-0 text-2xl animate-bounce" style={{ animationDelay: "3s" }}>
                    ✊
                  </div>
                </div>
              </div>

              {/* Bonding curve progress with enhanced visualization */}
              <Card className="mt-8 p-4 bg-card/50 backdrop-blur-sm border-primary/20">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-foreground">Bonding Curve Progress</h4>
                  <span className="text-xs text-muted-foreground">67% Complete</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 mb-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-primary via-secondary to-accent h-3 rounded-full relative animate-pulse"
                    style={{ width: "67%" }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                  </div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Launch</span>
                  <span className="text-primary font-semibold">Current: 67%</span>
                  <span>DEX Listing</span>
                </div>
                <p className="text-xs text-center text-accent mt-2">🎯 33% remaining until automatic DEX listing</p>
              </Card>

              {/* Additional stats */}
              <div className="mt-4 grid grid-cols-2 gap-4">
                <Card className="p-3 bg-card/30 backdrop-blur-sm text-center">
                  <p className="text-xs text-muted-foreground">Total Supply</p>
                  <p className="text-sm font-bold text-foreground">1B AMB</p>
                </Card>
                <Card className="p-3 bg-card/30 backdrop-blur-sm text-center">
                  <p className="text-xs text-muted-foreground">Circulating</p>
                  <p className="text-sm font-bold text-foreground">670M AMB</p>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
