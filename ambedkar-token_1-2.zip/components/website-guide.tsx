"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { X, ArrowRight, Home, Users, BarChart3, Map, BookOpen, Zap } from "lucide-react"

interface WebsiteGuideProps {
  isOpen: boolean
  onClose: () => void
}

export function WebsiteGuide({ isOpen, onClose }: WebsiteGuideProps) {
  const [currentStep, setCurrentStep] = useState(0)

  const guideSteps = [
    {
      title: "Welcome to AMBEDKAR Token",
      description:
        "Experience Dr. Ambedkar's vision through blockchain technology. This guide will show you around our revolutionary platform.",
      icon: <Home className="w-6 h-6" />,
      action: "Start Tour",
    },
    {
      title: "Revolution Section",
      description:
        "Learn about the digital revolution and how blockchain technology can create social equality. Discover the vision behind $AMB token.",
      icon: <Zap className="w-6 h-6" />,
      action: "Next",
    },
    {
      title: "Tokenomics",
      description:
        "Understand $AMB token distribution, supply mechanics, and how the bonding curve works on Pump.fun platform.",
      icon: <BarChart3 className="w-6 h-6" />,
      action: "Next",
    },
    {
      title: "Roadmap",
      description:
        "Explore our development phases from launch to DEX listing. See what milestones we're working towards.",
      icon: <Map className="w-6 h-6" />,
      action: "Next",
    },
    {
      title: "Community",
      description:
        "Join our growing community on social media platforms. Connect with fellow believers in equality and justice.",
      icon: <Users className="w-6 h-6" />,
      action: "Next",
    },
    {
      title: "Learn",
      description:
        "Educate yourself about Dr. Ambedkar's teachings and how they apply to modern blockchain technology.",
      icon: <BookOpen className="w-6 h-6" />,
      action: "Next",
    },
    {
      title: "Buy $AMB Token",
      description:
        "Ready to join the revolution? Click 'Buy $AMB on Pump.fun' to purchase tokens and become part of the equality movement!",
      icon: <ArrowRight className="w-6 h-6" />,
      action: "Finish Tour",
    },
  ]

  const handleNext = () => {
    if (currentStep < guideSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onClose()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  if (!isOpen) return null

  const currentGuide = guideSteps[currentStep]

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-background border-primary/20 shadow-2xl">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                {currentGuide.icon}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">{currentGuide.title}</h3>
                <p className="text-xs text-muted-foreground">
                  Step {currentStep + 1} of {guideSteps.length}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} className="text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-muted rounded-full h-2 mb-6">
            <div
              className="bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / guideSteps.length) * 100}%` }}
            ></div>
          </div>

          {/* Content */}
          <div className="mb-8">
            <p className="text-muted-foreground text-sm leading-relaxed">{currentGuide.description}</p>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className="text-sm bg-transparent"
            >
              Previous
            </Button>
            <div className="flex space-x-1">
              {guideSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-200 ${
                    index === currentStep ? "bg-primary" : index < currentStep ? "bg-primary/50" : "bg-muted"
                  }`}
                ></div>
              ))}
            </div>
            <Button onClick={handleNext} className="bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
              {currentGuide.action}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
