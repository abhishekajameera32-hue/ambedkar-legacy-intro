"use client"

import { useEffect, useRef, useState } from "react"

export function AmbedkarModel3D() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [rotation, setRotation] = useState(0)
  const [isHovered, setIsHovered] = useState(false)

  // Smooth rotation animation
  useEffect(() => {
    const interval = setInterval(() => {
      setRotation((prev) => (prev + 0.5) % 360)
    }, 50)

    return () => clearInterval(interval)
  }, [])

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Main 3D model representation */}
      <div
        className="absolute inset-0 transition-all duration-300"
        style={{
          transform: `rotateY(${rotation}deg) ${isHovered ? "scale(1.05)" : "scale(1)"}`,
          transformStyle: "preserve-3d",
        }}
      >
        {/* Outer glow ring */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 rounded-full animate-pulse blur-sm"></div>

        {/* Middle ring */}
        <div
          className="absolute inset-4 bg-gradient-to-br from-primary/40 via-secondary/40 to-accent/40 rounded-full animate-pulse"
          style={{ animationDelay: "1s", animationDuration: "3s" }}
        ></div>

        {/* Inner ring */}
        <div
          className="absolute inset-8 bg-gradient-to-br from-primary/60 via-secondary/60 to-accent/60 rounded-full animate-pulse"
          style={{ animationDelay: "2s", animationDuration: "2s" }}
        ></div>

        {/* Central figure - stylized representation */}
        <div className="absolute inset-16 bg-gradient-to-b from-primary to-secondary rounded-lg flex items-center justify-center relative overflow-hidden shadow-2xl">
          {/* Dr. Ambedkar's iconic 'A' */}
          <div className="text-6xl font-bold text-primary-foreground z-10 relative">
            A{/* Subtle inner glow */}
            <div className="absolute inset-0 text-6xl font-bold text-white/30 blur-sm">A</div>
          </div>

          {/* Glasses representation */}
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-12 h-6">
            <div className="absolute left-0 w-5 h-5 border-2 border-white/60 rounded-full"></div>
            <div className="absolute right-0 w-5 h-5 border-2 border-white/60 rounded-full"></div>
            <div className="absolute top-1/2 left-1/2 w-1 h-3 bg-white/60 transform -translate-x-1/2 -translate-y-1/2"></div>
          </div>

          {/* Constitutional elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-2 left-2 text-xs text-white/40 font-mono">Art. 14</div>
            <div className="absolute top-2 right-2 text-xs text-white/40 font-mono">Art. 15</div>
            <div className="absolute bottom-2 left-2 text-xs text-white/40 font-mono">Art. 16</div>
            <div className="absolute bottom-2 right-2 text-xs text-white/40 font-mono">Art. 17</div>
          </div>

          {/* Particle effects */}
          <div className="absolute inset-0">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-white/60 rounded-full animate-ping"
                style={{
                  top: `${20 + i * 10}%`,
                  left: `${20 + i * 8}%`,
                  animationDelay: `${i * 0.3}s`,
                  animationDuration: "2s",
                }}
              ></div>
            ))}
          </div>
        </div>

        {/* Blockchain network visualization */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Network nodes */}
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-3 h-3 bg-primary/60 rounded-full animate-pulse"
              style={{
                top: `${15 + Math.sin(i * 60 * (Math.PI / 180)) * 35 + 35}%`,
                left: `${15 + Math.cos(i * 60 * (Math.PI / 180)) * 35 + 35}%`,
                animationDelay: `${i * 0.5}s`,
              }}
            >
              {/* Connection lines */}
              <div
                className="absolute top-1/2 left-1/2 w-16 h-0.5 bg-gradient-to-r from-primary/40 to-transparent origin-left animate-pulse"
                style={{
                  transform: `translate(-50%, -50%) rotate(${i * 60}deg)`,
                  animationDelay: `${i * 0.5}s`,
                }}
              ></div>
            </div>
          ))}
        </div>
      </div>

      {/* Hover effect overlay */}
      {isHovered && (
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 rounded-full animate-pulse pointer-events-none"></div>
      )}

      {/* Interactive glow effect */}
      <div
        className={`absolute inset-0 rounded-full transition-all duration-300 ${
          isHovered ? "shadow-2xl shadow-primary/50" : "shadow-lg shadow-primary/20"
        }`}
      ></div>
    </div>
  )
}
