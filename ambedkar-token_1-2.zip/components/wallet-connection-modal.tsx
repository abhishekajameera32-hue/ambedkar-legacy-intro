"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useWallet } from "@/lib/wallet-context"

interface WalletConnectionModalProps {
  isOpen: boolean
  onClose: () => void
  onConnect: () => void
}

interface WalletOption {
  name: string
  icon: string
  detected: boolean
  popular?: boolean
  description: string
}

export function WalletConnectionModal({ isOpen, onClose, onConnect }: WalletConnectionModalProps) {
  const { connect, isConnecting } = useWallet()
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null)
  const [connectionStatus, setConnectionStatus] = useState<"idle" | "requesting" | "awaiting" | "success" | "error">(
    "idle",
  )
  const [errorMessage, setErrorMessage] = useState("")

  const walletOptions: WalletOption[] = [
    {
      name: "Phantom",
      icon: "👻",
      detected: typeof window !== "undefined" && !!(window as any).phantom,
      popular: true,
      description: "A friendly Solana wallet built for DeFi & NFTs",
    },
    {
      name: "Solflare",
      icon: "🔥",
      detected: typeof window !== "undefined" && !!(window as any).solflare,
      description: "Solflare is a non-custodial wallet for Solana",
    },
    {
      name: "Backpack",
      icon: "🎒",
      detected: typeof window !== "undefined" && !!(window as any).backpack,
      description: "A home for your xNFTs",
    },
    {
      name: "Glow",
      icon: "✨",
      detected: false,
      description: "Simple and secure Solana wallet",
    },
    {
      name: "Slope",
      icon: "📈",
      detected: false,
      description: "Slope Finance Wallet",
    },
    {
      name: "Sollet",
      icon: "💼",
      detected: false,
      description: "SPL Token Wallet",
    },
  ]

  const handleWalletSelect = async (walletName: string) => {
    const wallet = walletOptions.find((w) => w.name === walletName)
    if (!wallet?.detected) {
      window.open(getWalletInstallUrl(walletName), "_blank")
      return
    }

    setSelectedWallet(walletName)
    setConnectionStatus("requesting")

    try {
      setConnectionStatus("awaiting")
      await connect(walletName)
      setConnectionStatus("success")
      setTimeout(() => {
        onConnect()
        handleClose()
      }, 1500)
    } catch (error) {
      setConnectionStatus("error")
      setErrorMessage(error instanceof Error ? error.message : "Connection failed")
    }
  }

  const handleClose = () => {
    if (!isConnecting) {
      setSelectedWallet(null)
      setConnectionStatus("idle")
      setErrorMessage("")
      onClose()
    }
  }

  const handleRetry = () => {
    setConnectionStatus("idle")
    setSelectedWallet(null)
    setErrorMessage("")
  }

  const getWalletInstallUrl = (walletName: string): string => {
    const urls: Record<string, string> = {
      Phantom: "https://phantom.app/",
      Solflare: "https://solflare.com/",
      Backpack: "https://backpack.app/",
      Glow: "https://glow.app/",
      Slope: "https://slope.finance/",
      Sollet: "https://www.sollet.io/",
    }
    return urls[walletName] || "#"
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg bg-card border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold text-foreground">
            Connect Your Wallet to the Revolution
          </DialogTitle>
          <DialogDescription className="text-center text-muted-foreground">
            Choose your wallet to join the movement and acquire $AMB tokens
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {connectionStatus === "idle" && (
            <>
              {/* Wallet Grid */}
              <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto">
                {walletOptions.map((wallet) => (
                  <Card
                    key={wallet.name}
                    className={`p-4 cursor-pointer transition-all duration-200 border-2 ${
                      wallet.detected
                        ? "hover:border-primary hover:bg-primary/5 border-border"
                        : "hover:border-accent hover:bg-accent/5 border-muted"
                    } ${wallet.popular ? "ring-2 ring-primary/20" : ""}`}
                    onClick={() => handleWalletSelect(wallet.name)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="text-3xl">{wallet.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <p className="font-semibold text-foreground">{wallet.name}</p>
                          {wallet.popular && (
                            <span className="px-2 py-1 text-xs bg-primary/20 text-primary rounded-full">Popular</span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{wallet.description}</p>
                        <p className="text-xs font-medium">
                          {wallet.detected ? (
                            <span className="text-green-500">✓ Detected</span>
                          ) : (
                            <span className="text-accent">Install Wallet</span>
                          )}
                        </p>
                      </div>
                      <div className="text-muted-foreground">
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path
                            fillRule="evenodd"
                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Help text */}
              <div className="text-center text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
                <p className="mb-1">New to Solana wallets?</p>
                <a href="#" className="text-primary hover:underline font-medium">
                  Learn how to get started with Web3 wallets
                </a>
              </div>
            </>
          )}

          {connectionStatus === "requesting" && (
            <div className="text-center py-8">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Requesting connection...</h3>
              <p className="text-muted-foreground">Initializing {selectedWallet} wallet</p>
            </div>
          )}

          {connectionStatus === "awaiting" && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <span className="text-2xl">{walletOptions.find((w) => w.name === selectedWallet)?.icon || "👻"}</span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Awaiting approval in {selectedWallet}...</h3>
              <p className="text-muted-foreground">Please approve the connection request in your wallet extension</p>
              <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                <p className="text-sm text-accent">
                  💡 Check your browser extensions or look for a {selectedWallet} popup window
                </p>
              </div>
            </div>
          )}

          {connectionStatus === "success" && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <span className="text-2xl text-green-500">✅</span>
              </div>
              <h3 className="text-lg font-semibold text-green-500 mb-2">Wallet Connected Successfully!</h3>
              <p className="text-muted-foreground">Welcome to the AMBEDKAR revolution</p>
              <div className="mt-4 p-3 bg-green-500/10 rounded-lg">
                <p className="text-sm text-green-600">🎉 You can now participate in token purchases and governance</p>
              </div>
            </div>
          )}

          {connectionStatus === "error" && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-red-500">❌</span>
              </div>
              <h3 className="text-lg font-semibold text-red-500 mb-2">Connection Failed</h3>
              <p className="text-muted-foreground mb-4">{errorMessage || "Please try again"}</p>
              <div className="space-y-2">
                <Button onClick={handleRetry} className="bg-primary hover:bg-primary/90 text-primary-foreground w-full">
                  Try Again
                </Button>
                <Button onClick={handleClose} variant="outline" className="w-full bg-transparent">
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
