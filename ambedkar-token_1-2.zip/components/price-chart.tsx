"use client"

import { useEffect, useRef } from "react"

interface PricePoint {
  timestamp: number
  price: number
  volume: number
}

interface PriceChartProps {
  data: PricePoint[]
}

export function PriceChart({ data }: PriceChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || data.length === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * window.devicePixelRatio
    canvas.height = rect.height * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    const width = rect.width
    const height = rect.height
    const padding = 40

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Find min/max values
    const prices = data.map((d) => d.price)
    const minPrice = Math.min(...prices)
    const maxPrice = Math.max(...prices)
    const priceRange = maxPrice - minPrice || 0.000001

    // Draw grid lines
    ctx.strokeStyle = "rgba(192, 161, 110, 0.1)"
    ctx.lineWidth = 1

    // Horizontal grid lines
    for (let i = 0; i <= 4; i++) {
      const y = padding + (i * (height - 2 * padding)) / 4
      ctx.beginPath()
      ctx.moveTo(padding, y)
      ctx.lineTo(width - padding, y)
      ctx.stroke()
    }

    // Vertical grid lines
    for (let i = 0; i <= 6; i++) {
      const x = padding + (i * (width - 2 * padding)) / 6
      ctx.beginPath()
      ctx.moveTo(x, padding)
      ctx.lineTo(x, height - padding)
      ctx.stroke()
    }

    // Draw price line
    ctx.strokeStyle = "rgba(192, 161, 110, 1)"
    ctx.lineWidth = 2
    ctx.beginPath()

    data.forEach((point, index) => {
      const x = padding + (index * (width - 2 * padding)) / (data.length - 1)
      const y = height - padding - ((point.price - minPrice) / priceRange) * (height - 2 * padding)

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })

    ctx.stroke()

    // Draw gradient fill
    ctx.fillStyle = "rgba(192, 161, 110, 0.1)"
    ctx.beginPath()

    data.forEach((point, index) => {
      const x = padding + (index * (width - 2 * padding)) / (data.length - 1)
      const y = height - padding - ((point.price - minPrice) / priceRange) * (height - 2 * padding)

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })

    ctx.lineTo(width - padding, height - padding)
    ctx.lineTo(padding, height - padding)
    ctx.closePath()
    ctx.fill()

    // Draw data points
    ctx.fillStyle = "rgba(192, 161, 110, 1)"
    data.forEach((point, index) => {
      const x = padding + (index * (width - 2 * padding)) / (data.length - 1)
      const y = height - padding - ((point.price - minPrice) / priceRange) * (height - 2 * padding)

      ctx.beginPath()
      ctx.arc(x, y, 3, 0, 2 * Math.PI)
      ctx.fill()
    })

    // Draw labels
    ctx.fillStyle = "rgba(107, 114, 128, 1)"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"

    // Price labels (Y-axis)
    for (let i = 0; i <= 4; i++) {
      const price = minPrice + (i * priceRange) / 4
      const y = height - padding - (i * (height - 2 * padding)) / 4
      ctx.textAlign = "right"
      ctx.fillText(`$${price.toFixed(6)}`, padding - 5, y + 4)
    }

    // Time labels (X-axis)
    ctx.textAlign = "center"
    for (let i = 0; i < data.length; i += Math.ceil(data.length / 6)) {
      const x = padding + (i * (width - 2 * padding)) / (data.length - 1)
      const time = new Date(data[i].timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      ctx.fillText(time, x, height - padding + 20)
    }
  }, [data])

  return (
    <div className="w-full h-64 relative">
      <canvas ref={canvasRef} className="w-full h-full" style={{ width: "100%", height: "100%" }} />
    </div>
  )
}
