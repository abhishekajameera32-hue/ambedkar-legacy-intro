"use client"

import { useEffect, useRef } from "react"

interface HoldersChartProps {
  holders: number
}

export function HoldersChart({ holders }: HoldersChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * window.devicePixelRatio
    canvas.height = rect.height * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    const width = rect.width
    const height = rect.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 3

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Simulate holder distribution
    const distributions = [
      { label: "Small Holders (<100 AMB)", percentage: 45, color: "rgba(25, 118, 210, 0.8)" },
      { label: "Medium Holders (100-10K AMB)", percentage: 35, color: "rgba(192, 161, 110, 0.8)" },
      { label: "Large Holders (10K-100K AMB)", percentage: 15, color: "rgba(211, 47, 47, 0.8)" },
      { label: "Whales (>100K AMB)", percentage: 5, color: "rgba(107, 114, 128, 0.8)" },
    ]

    let currentAngle = -Math.PI / 2 // Start from top

    // Draw pie chart
    distributions.forEach((segment) => {
      const sliceAngle = (segment.percentage / 100) * 2 * Math.PI

      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle)
      ctx.closePath()
      ctx.fillStyle = segment.color
      ctx.fill()

      // Draw border
      ctx.strokeStyle = "rgba(255, 255, 255, 0.3)"
      ctx.lineWidth = 2
      ctx.stroke()

      currentAngle += sliceAngle
    })

    // Draw center circle with total holders
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius * 0.4, 0, 2 * Math.PI)
    ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
    ctx.fill()

    ctx.fillStyle = "white"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(`${holders.toLocaleString()}`, centerX, centerY - 5)
    ctx.font = "12px sans-serif"
    ctx.fillText("Total Holders", centerX, centerY + 15)

    // Draw legend
    const legendX = width - 150
    const legendY = 30

    distributions.forEach((segment, index) => {
      const y = legendY + index * 25

      // Color box
      ctx.fillStyle = segment.color
      ctx.fillRect(legendX, y, 15, 15)

      // Text
      ctx.fillStyle = "rgba(107, 114, 128, 1)"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(`${segment.percentage}%`, legendX + 20, y + 12)
    })
  }, [holders])

  return (
    <div className="w-full h-64 relative">
      <canvas ref={canvasRef} className="w-full h-full" style={{ width: "100%", height: "100%" }} />
      <div className="absolute bottom-4 left-4 text-xs text-muted-foreground">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-accent rounded-sm"></div>
            <span>Small Holders</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-sm"></div>
            <span>Medium Holders</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-secondary rounded-sm"></div>
            <span>Large Holders</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-muted-foreground rounded-sm"></div>
            <span>Whales</span>
          </div>
        </div>
      </div>
    </div>
  )
}
